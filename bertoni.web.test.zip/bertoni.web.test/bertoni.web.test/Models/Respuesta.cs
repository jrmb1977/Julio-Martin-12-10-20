﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace bertoni.web.test.Models
{
    public class Respuesta
    {
        public string Codigo { get; set; }
        public string Mensaje { get; set; }
    }
}