﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace bertoni.web.test.Models
{
    public class itemLista
    {
        public string texto { get; set; }
        public string url { get; set; }
    }
}